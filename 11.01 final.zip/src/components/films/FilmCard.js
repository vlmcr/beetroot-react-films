import React from 'react';
import PropTypes from 'prop-types';
import Featured from "./Featured";

const FilmCard = ({film}) => {
    console.log("---- rendered ---", film._id);

    return (

        <div className="ui card">
            <div className="image">
                <span className="ui green label ribbon">$ {film.price} </span>
                <Featured id={film._id} featured={film.featured} />
                <img src={film.img} alt="" />
            </div>

            <div className="content">
                <span href="#" className="header">{film.title}</span>

                <div className="meta">
                    <i className="icon users" /> {film.director}
                    <span className="right floated">
                <i className="icon wait right" /> {film.duration} min
            </span>
                </div>
            </div>
        </div>
    )
}



FilmCard.propTypes = {
    film: PropTypes.shape({
        price: PropTypes.number.isRequired,
        img: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        director: PropTypes.string.isRequired,
        duration: PropTypes.number.isRequired,
        featured: PropTypes.bool.isRequired,
    })
}


export default React.memo(FilmCard);